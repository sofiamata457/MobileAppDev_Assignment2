package com.example.assignment2;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
/**
 * Assignment 2
 * MainActivity.java
 * Sofia Mata Avila
 * Senaye Welderberhan
 * */
public class MainActivity extends AppCompatActivity {
    final String TAG = "demo";
    View view;
    SeekBar seekbar1;
    SeekBar seekbar2;
    SeekBar seekbar3;
    TextView seekbar_text1;
    TextView seekbar_text2;
    TextView seekbar_text3;
    TextView color_hex;
    TextView colorRBG;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.rootView), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        seekbar1 = findViewById(R.id.seekbar1);
        seekbar2 = findViewById(R.id.seekbar2);
        seekbar3 = findViewById(R.id.seekbar3);
        seekbar_text1 = findViewById(R.id.seekbar_text1);
        seekbar_text2 = findViewById(R.id.seekbar_text2);
        seekbar_text3 = findViewById(R.id.seekbar_text3);
        colorRBG = findViewById(R.id.colorRGB);
        color_hex = findViewById(R.id.color_hex);

        // Initial display when the app is first opened
        CharSequence starting_info = "Color RGB: (" + 64 + ", " + 128 + ", " + 0 + ")";
        // view display
        findViewById(R.id.colorview).setBackgroundColor(Color.rgb(Integer.parseInt(String.valueOf(seekbar_text1.getText())),Integer.parseInt(String.valueOf(seekbar_text2.getText())),Integer.parseInt(String.valueOf(seekbar_text3.getText()))));
        // color hex display
        color_hex.setText (String.format("#%02X%02X%02X", Integer.parseInt(String.valueOf(seekbar_text1.getText())), Integer.parseInt(String.valueOf(seekbar_text1.getText())), Integer.parseInt(String.valueOf(seekbar_text1.getText())) ));
        // color rgb display
        colorRBG.setText(starting_info);

        
        // Red seekbar
        seekbar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                seekbar_text1.setText(String.valueOf(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                Log.d(TAG, "onStartTrackingTouch: ");
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Log.d(TAG, "onStopTrackingTouch: ");
                // sets the color on the view
                findViewById(R.id.colorview).setBackgroundColor(Color.rgb(Integer.parseInt(String.valueOf(seekbar_text1.getText())),Integer.parseInt(String.valueOf(seekbar_text2.getText())),Integer.parseInt(String.valueOf(seekbar_text3.getText()))));
                // char variable holding the new information for the text
                CharSequence info = "Color RGB: (" + seekbar_text1.getText() + ", " + seekbar_text2.getText() + ", " + seekbar_text3.getText() + ")";
                // setting the new text for color rgb
                colorRBG.setText(info);
                // setting the new text for color hex
                color_hex.setText (String.format("#%02X%02X%02X", Integer.parseInt(String.valueOf(seekbar_text1.getText())), Integer.parseInt(String.valueOf(seekbar_text1.getText())), Integer.parseInt(String.valueOf(seekbar_text1.getText())) ));

            }
        });

        // Green seekbar
        seekbar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                seekbar_text2.setText(String.valueOf(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                Log.d(TAG, "onStartTrackingTouch: ");
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Log.d(TAG, "onStopTrackingTouch: ");
                // sets the color on the view
                findViewById(R.id.colorview).setBackgroundColor(Color.rgb(Integer.parseInt(String.valueOf(seekbar_text1.getText())),Integer.parseInt(String.valueOf(seekbar_text2.getText())),Integer.parseInt(String.valueOf(seekbar_text3.getText()))));
                // char variable holding the new information for the text
                CharSequence info = "Color RGB: (" + seekbar_text1.getText() + ", " + seekbar_text2.getText() + ", " + seekbar_text3.getText() + ")";
                // setting the new text for color rgb
                colorRBG.setText(info);
                // setting the new text for color hex
                color_hex.setText (String.format("#%02X%02X%02X", Integer.parseInt(String.valueOf(seekbar_text1.getText())), Integer.parseInt(String.valueOf(seekbar_text1.getText())), Integer.parseInt(String.valueOf(seekbar_text1.getText())) ));

            }
        });

        // Blue seekbar
        seekbar3.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                seekbar_text3.setText(String.valueOf(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                Log.d(TAG, "onStartTrackingTouch: ");
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Log.d(TAG, "onStopTrackingTouch: ");
                // sets the color on the view
                findViewById(R.id.colorview).setBackgroundColor(Color.rgb(Integer.parseInt(String.valueOf(seekbar_text1.getText())),Integer.parseInt(String.valueOf(seekbar_text2.getText())),Integer.parseInt(String.valueOf(seekbar_text3.getText()))));
                // char variable holding the new information for the text
                CharSequence info = "Color RGB: (" + seekbar_text1.getText() + ", " + seekbar_text2.getText() + ", " + seekbar_text3.getText() + ")";
                // setting the new text for color rgb
                colorRBG.setText(info);
                // setting the new text for color hex
                color_hex.setText (String.format("#%02X%02X%02X", Integer.parseInt(String.valueOf(seekbar_text1.getText())), Integer.parseInt(String.valueOf(seekbar_text1.getText())), Integer.parseInt(String.valueOf(seekbar_text1.getText())) ));
            }
        });


















    }
}